<section class="content reports">
    <div class="row">
    	<div class="col-md-12">
    		<form class="formList">
			    <div class="box box-solid">
			        <div class="box-body">
			        	<div class="report_posts"></div>
			        </div>
			    </div>
		    </form>
		</div>
    </div>
</section>
<script type="text/javascript">
	$(function(){
		Main.chart();
	});
</script>