<section class="content-header">
    <h1>
        Change password
        <small>user</small>
    </h1>
    
</section>

<section class="content">
    <div class="box box-info">
        <form class="form-horizontal formUpdatePassword">
            <div class="box-body">
                <div class="form-group">
                    <label for="password-old" class="col-sm-3 control-label">Old Password</label>
                    <div class="col-sm-5">
                        <input type="password" class="form-control" id="password-old" name="password_old" autocomplete="off">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">New Password</label>
                    <div class="col-sm-5">
                        <input type="password" class="form-control" id="password" name="password" autocomplete="off">
                    </div>
                </div>
                <div class="form-group">
                    <label for="re-password" class="col-sm-3 control-label">Re-New password</label>
                    <div class="col-sm-5">
                        <input type="password" class="form-control" id="re-password" name="repassword" autocomplete="off">
                    </div>
                </div>
                <div class="form-group">
                    <label for="re-password" class="col-sm-3 control-label">&nbsp;</label>
                     <div class="col-sm-5">
                        <div class="msg"></div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-info pull-right">Submit</button>
            </div>
        </form>
    </div>
</section>