<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - طلب إعادة تعيين كلمة المرور';
$_['text_greeting'] = 'تم طلب كلمة مرور جديدة من %s .';
$_['text_change']   = 'لإعادة تعيين كلمة المرور انقر على الرابط أدناه:';
$_['text_ip']       = 'عنوان الآي بي الذي تم طلب منه إعادة تعيين كلمة المرور هو: %s';
